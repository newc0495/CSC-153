﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleUI
{
    class Program
    {
        static void Main(string[] args)
        {
            Random rnd = new Random();
            Lib.Item[] items = { new Lib.Item("Something Great", rnd.Next(1, 5)) }; 
            bool exit = false;
            do
            {
                Console.WriteLine("1. Next room \n2. Check Item \n3. Exit Program");
                Console.Write("Enter an option: ");
                switch (Console.ReadLine())
                {
                    case "1":
                        int length = rnd.Next(1, 100);
                        int width = rnd.Next(1, 100);
                        Lib.Room room = new Lib.Room(length, width);
                        Console.WriteLine($"The room is {length} ft long and {width} ft wide.");
                        break;
                    case "2":
                        Console.WriteLine(Lib.Item.GetItem(items[0]));
                        break;
                    case "3":
                        exit = true;
                        break;
                    default:
                        break;
                }

            } while (exit == false);
        }
    }
}

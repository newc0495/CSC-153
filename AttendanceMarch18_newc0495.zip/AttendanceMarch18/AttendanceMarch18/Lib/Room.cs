﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lib
{
    public class Room
    {
        // Fields
        private int _length;
        private int _width;

        // Properties
        public int Length
        {
            get
            {
                return _length;
            }
            set
            {
                _length = value;
            }
        }

        public int Width
        {
            get
            {
                return _width;
            }
            set
            {
                _width = value;
            }
        }

        // Constructor
        public Room(int length, int width)
        {
            Length = length;
            Width = width;
        }
    }
}

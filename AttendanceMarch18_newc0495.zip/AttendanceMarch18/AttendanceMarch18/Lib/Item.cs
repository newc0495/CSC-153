﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lib
{
    public class Item
    {
        // Fields
        private string _name;
        private int _rarity;

        // Properties
        public string Name
        {
            get
            {
                return _name;
            }
            set
            {
                _name = value;
            }
        }

        public int Rarity
        {
            get
            {
                return _rarity;
            }
            set
            {
                _rarity = value;
            }
        }

        // Constructor
        public Item(string name, int rarity)
        {
            Name = name;
            Rarity = rarity;
        }

        public static string GetItem(Item item)
        {
            {
                return $"Item: {item.Name} \nRarity: {item.Rarity}";
            }
        }
    }
}

﻿using System;

namespace ClassLibrary
{
    public class Car
    {
        // Fields
        private int _year;
        private string _make;
        private int _speed;

        //Properties
        public int Year
        {
            get
            {
                return _year;
            }
            set
            {
                _year = value;
            }
        }

        public string Make
        {
            get
            {
                return _make;
            }
            set
            {
                _make = value;
            }
        }

        public int Speed { get; set; }

        // Constructor
        public Car()
        {
            Make = "";
            Year = 1900;
            Speed = 0;
        }
        public Car(int year, string make, int speed)
        {
            Make = _make;
            Year = _year;
            Speed = 0;
        }

        // Methods
        public static string Accelerate(Car thisCar)
        {
            thisCar.Speed += 5;
            return $"The {thisCar.Year} {thisCar.Make} is now going {thisCar.Speed}mph.";
        }

        public static string Brake(Car thisCar)
        {
            if (thisCar.Speed == 0)
            {
                return $"The {thisCar.Year} {thisCar.Make} is already stopped.";
            }
            else
            {
                thisCar.Speed -= 5;
                return $"The {thisCar.Year} {thisCar.Make} is now going {thisCar.Speed}mph."; 
            }
        }

        public static void CreateCar(Car thisCar)
        {
            Console.WriteLine("Let's build a car!");
            Console.WriteLine("What is the car's year?: ");
            thisCar.Year = StandardMessages.MakeInt(Console.ReadLine());
            if (thisCar.Year < 1900)
            {
                Console.WriteLine($"{thisCar.Year} is not a valid year. Please try again.");
            }
            else
            {
                Console.WriteLine("What is the car's make?: ");
                thisCar.Make = Console.ReadLine();

                Console.WriteLine("Your car has been created!");
                Console.WriteLine($"Year: {thisCar.Year} \nMake: {thisCar.Make}");
            }
        }
    }
}

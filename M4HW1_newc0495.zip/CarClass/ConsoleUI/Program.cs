﻿using System;

/*
* 03/20/2020
* CSC 153
* Christian New
* User creates a car,
* car can accelerate infinitely,
* car can decelerate until stopped.
*/

namespace ConsoleUI
{
    class Program
    {
        static void Main(string[] args)
        {
            ClassLibrary.Car thisCar = new ClassLibrary.Car();
            bool exit = false;
            do
            {
                Console.WriteLine(ClassLibrary.StandardMessages.Menu());
                switch (ClassLibrary.StandardMessages.GetInput())
                {
                    case "1":
                        // Create a car
                        ClassLibrary.Car.CreateCar(thisCar);
                        break;
                    case "2":
                        // Accelerate the car
                        Console.WriteLine(ClassLibrary.Car.Accelerate(thisCar));
                        break;
                    case "3":
                        // Decelerate the car
                        Console.WriteLine(ClassLibrary.Car.Brake(thisCar));
                        break;
                    case "4":
                        // Exit Program
                        exit = true;
                        break;
                    default:
                        Console.WriteLine(ClassLibrary.StandardMessages.InvalidInput());
                        break;
                }
            } while (exit == false);
        }
    }
}

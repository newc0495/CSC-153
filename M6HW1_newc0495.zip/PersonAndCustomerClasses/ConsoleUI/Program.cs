﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ClassLibrary;

/* 04/23/20
 * CSC 153
 * Christian New
 * Program creates customers with
 * inherited properties from Person class
 */

namespace ConsoleUI
{
    class Program
    {
        static void Main(string[] args)
        {
            List<Customer> customers = new List<Customer>();

            bool exit = false;
            do
            {
                Console.WriteLine(Util.DisplayMenu());
                switch (Console.ReadLine())
                {
                    case "1":
                        Util.EnterInfo(customers);
                        break;
                    case "2":
                        Util.DisplayInfo(customers);
                        break;
                    case "3":
                        exit = true;
                        break;
                    default:
                        Console.WriteLine("Not a valid choice. Try again.");
                        break;
                }
            } while (exit == false);
        }
    }
}

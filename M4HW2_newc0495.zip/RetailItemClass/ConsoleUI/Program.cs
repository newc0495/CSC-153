﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Lib;

/* 03/27/20
 * CSC 153
 * Christian New
 * Program displays short list of
 * retail items, their price, and count.
 */

namespace ConsoleUI
{
    class Program
    {
        static void Main(string[] args)
        {
            bool exit = false;
            do
            {
                List<RetailItem> retailItems = new List<RetailItem>();
                Console.WriteLine(Utils.Menu());
                switch (Utils.GetInput())
                {
                    case "1":
                        retailItems.Add(new RetailItem { Desc = "Jacket", UnitsOnHand = 12, Price = 59.05m });
                        retailItems.Add(new RetailItem { Desc = "Jeans", UnitsOnHand = 40, Price = 34.95m });
                        retailItems.Add(new RetailItem { Desc = "Shirt", UnitsOnHand = 20, Price = 24.95m });
                        foreach (var item in retailItems)
                        {
                            Console.WriteLine($"Item: {item.Desc} Count: {item.UnitsOnHand} Price: ${item.Price}");
                        }
                        break;
                    case "2":
                        exit = true;
                        break;
                    default:
                        Utils.InvalidInput();
                        break;
                }
            } while (exit == false); ;
        }
    }
}

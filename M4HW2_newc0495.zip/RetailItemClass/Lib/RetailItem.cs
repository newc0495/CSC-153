﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lib
{
    public class RetailItem
    {
        // Fields
        private string _desc;
        private int _unitsOnHand;
        private decimal price;

        // Properties
        public string Desc { get => _desc; set => _desc = value; }
        public int UnitsOnHand { get => _unitsOnHand; set => _unitsOnHand = value; }
        public decimal Price { get => price; set => price = value; }

        // Constructor
        public RetailItem()
        {
            Desc = "";
            UnitsOnHand = 0;
            Price = 0.00m;
        }

        public RetailItem(string desc, int unitsOnHand, decimal price)
        {
            Desc = desc;
            UnitsOnHand = unitsOnHand;
            Price = price;
        }
    }
}

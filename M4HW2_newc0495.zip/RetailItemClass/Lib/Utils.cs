﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lib
{
    public class Utils
    {
        public static string Menu()
        {
            return "1. Run program \n2. Exit";
        }

        public static string GetInput()
        {
            Console.WriteLine("Enter an option: ");
            string input = Console.ReadLine();
            return input;
        }

        public static string InvalidInput()
        {
            return "That's not a valid input. Please try again.";
        }
    }
}

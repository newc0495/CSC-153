﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ClassLibrary;

/*
 * 04/30/20
 * CSC 153
 * Christian New
 * Program allows user to input customer info
 * and display this info from a list of customers.
 * User can submit purchases to a specific customer's
 * cart, which in turn updates the customer's
 * Purchase History and Discount Level attributes.
 * CAUTION: Customer list is not saved
 * when exiting program.
 */

namespace ConsoleUI
{
    class Program
    {
        static void Main(string[] args)
        {
            List<Person> allCustomers = new List<Person>();
            bool exit = false;
            do
            {
                Console.WriteLine(Util.DisplayMenu());
                switch (Console.ReadLine())
                {
                    case "1":
                        Util.EnterInfo(allCustomers);
                        break;
                    case "2":
                        Util.DisplayInfo(allCustomers);
                        break;
                    case "3":
                        Util.SubmitCart(allCustomers);
                        break;
                    case "4":
                        exit = true;
                        break;
                    default:
                        Console.WriteLine(Util.InvalidInput());
                        break;
                }
            } while (exit == false);
        }
    }
}
